
package juegoahorcado;

import java.util.Scanner;

/**
 *
 * @author usuario
 */
public class JuegoAhorcado {

    private static Palabra palabraParaAdivinar;
    private static Palabra palabraAdivinada;
    private static String letrasUsadas; //letras usadas, separadas por espacios
    private static int vidas; //hay 6
    private static int numPartidas; //se juega al mejor de 5

    public JuegoAhorcado() {
        vidas = 6;
        letrasUsadas = "";
    }

    public static int getVidas() {
        return vidas;
    }
    
    /**
     * 
     * @param letra es la letra a buscar en la palabra
     * @return true si se encuentra la letra en la palabra, false si no se encuentra
     */
    public static boolean preguntarLetra(char letra) {
        String aux = "";
        String aux2 = "";
        boolean encontrada = false;

        if (palabraParaAdivinar.numeroLetras() != 0) {
            for (int i = 0; i < palabraParaAdivinar.numeroLetras(); i++) //recorremos la palabra en búsqueda de la letra
            { 
                if (letra == (palabraParaAdivinar.getPalabra().charAt(i))) {
                    aux2 = aux2 + letra;
                    encontrada = true;
                } else {
                    aux2 = aux2 + palabraAdivinada.getPalabra().charAt(i);
                    aux = aux.concat(aux2);
                }
            }
            palabraAdivinada.setPalabra(aux2);
        }
        return encontrada;
    }

    public static void guardarUsadas(char letra) {
        letrasUsadas = letrasUsadas + letra;
    }

    public static void inicializarAdivinada() {
        String cadena2 = "", var2 = "*";
        for (int i = 0; i < palabraParaAdivinar.numeroLetras(); i++) {
            cadena2 = cadena2.concat(var2);
        }
        palabraAdivinada = new Palabra(cadena2);
    }

    /**
     * 
     * @return true si la palabra es corecta, false en caso contrario
     */
    public static boolean acierta() {
        return (palabraAdivinada.getPalabra().equals(palabraParaAdivinar.getPalabra()));
    }

    /**
     * Se ha cogido esta estructura de internet
     */
    public static void dibujarAhorcado() {
        switch (vidas) {
            case 6:
                System.out.println(" ---------------------");
                for (int j = 0; j < 15; j++) {
                    System.out.println(" |");
                }   System.out.println("__________");
                break;
            case 5:
                System.out.println(" ---------------------");
                System.out.println(" |                     |");
                System.out.println(" |                     |");
                System.out.println(" |                  -------");
                System.out.println(" |                 | -  -  |");
                System.out.println(" |                 |   o   |");
                System.out.println(" |                  -------");
                for (int j = 0; j < 10; j++) {
                    System.out.println(" |");
                }   System.out.println("__________");
                break;
            case 4:
                System.out.println(" ---------------------");
                System.out.println(" |                     |");
                System.out.println(" |                     |");
                System.out.println(" |                  -------");
                System.out.println(" |                 | -  -  |");
                System.out.println(" |                 |   o   |");
                System.out.println(" |                  -------");
                System.out.println(" |                     |   ");
                System.out.println(" |                     |   ");
                System.out.println(" |                     |   ");
                System.out.println(" |                     |   ");
                System.out.println(" |                     |   ");
                for (int j = 0; j < 5; j++) {
                    System.out.println(" |");
                }   System.out.println("__________");
                break;
            case 3:
                System.out.println(" ---------------------");
                System.out.println(" |                     |");
                System.out.println(" |                     |");
                System.out.println(" |                  -------");
                System.out.println(" |                 | -  -  |");
                System.out.println(" |                 |   o   |");
                System.out.println(" |                  -------");
                System.out.println(" |                     |   ");
                System.out.println(" |                   / |   ");
                System.out.println(" |                 /   |   ");
                System.out.println(" |                /    |   ");
                System.out.println(" |                     |   ");
                for (int j = 0; j < 5; j++) {
                    System.out.println(" |");
                }   System.out.println("__________");
                break;
            case 2:
                System.out.println(" ---------------------");
                System.out.println(" |                     |");
                System.out.println(" |                     |");
                System.out.println(" |                  -------");
                System.out.println(" |                 | -  -  |");
                System.out.println(" |                 |   o   |");
                System.out.println(" |                  -------");
                System.out.println(" |                     |   ");
                System.out.println(" |                   / | \\ ");
                System.out.println(" |                  /  |   \\ ");
                System.out.println(" |                 /   |     \\ ");
                System.out.println(" |                     |   ");
                for (int j = 0; j < 5; j++) {
                    System.out.println(" |");
                }   System.out.println("__________");
                break;
            case 1:
                System.out.println(" ---------------------");
                System.out.println(" |                     |");
                System.out.println(" |                     |");
                System.out.println(" |                  -------");
                System.out.println(" |                 | -  -  |");
                System.out.println(" |                 |   o   |");
                System.out.println(" |                  -------");
                System.out.println(" |                     |   ");
                System.out.println(" |                   / | \\ ");
                System.out.println(" |                  /  |   \\ ");
                System.out.println(" |                 /   |     \\ ");
                System.out.println(" |                     |   ");
                System.out.println(" |                    /  ");
                System.out.println(" |                   /      ");
                System.out.println(" |                  /       ");
                for (int j = 0; j < 2; j++) {
                    System.out.println(" |");
                }   System.out.println("__________");
                break;
            case 0:
                System.out.println(" ---------------------");
                System.out.println(" |                     |");
                System.out.println(" |                     |");
                System.out.println(" |                  -------");
                System.out.println(" |                 | X  X  |");
                System.out.println(" |                 |   o   |");
                System.out.println(" |                  -------");
                System.out.println(" |                     |   ");
                System.out.println(" |                   / | \\ ");
                System.out.println(" |                  /  |   \\ ");
                System.out.println(" |                 /   |     \\ ");
                System.out.println(" |                     |   ");
                System.out.println(" |                    / \\");
                System.out.println(" |                   /   \\  ");
                System.out.println(" |                  /     \\ ");
                for (int j = 0; j < 2; j++) {
                    System.out.println(" |");
                }   System.out.println("__________");
                break;
            default:
                break;
        }
    }

    public static void pierdeVida() {
        vidas--;
    }

    public static void main(String[] args) {
        
        Jugador Jugador1 = new Jugador();
        Jugador Jugador2 = new Jugador();
        Scanner entero = new Scanner(System.in);
        Scanner sx = new Scanner(System.in);
        char letra;
        System.out.println("----- EL JUEGO DEL AHORCADO -----\n");
        System.out.println("\tINSTRUCCIONES:");
        System.out.println("Se juega al mejor de 5 partidas. Por tanto, gana el jugador que gane primero 3 partidas.");
        System.out.println("En cada partida, un jugador alternativamente escribe una palabra.");
        System.out.println("El jugador tiene 2 opciones: \n \t-Eligir letra. Si la letra elegida no está en la palabra, pierde una vida (tiene 6 vidas inicialmente). \n \t-Acertar palabra. Si la palabra es errónea, pierde una vida (tiene 6 vidas inicialmente).");
        System.out.println("El juego termina cuando...");
        System.out.println("\t-El jugador adivina la palabra.");
        System.out.println("\t-El jugador pierde todas las vidas.\n");
        System.out.println("---------------------------------");
        int i=0;
        int j=0;
        while (numPartidas != 5 && !Jugador1.ganador() && !Jugador2.ganador()) {
            System.out.println("\nMARCADOR:");
            System.out.println("Jugador 1: " + Jugador1.getGanadas());
            System.out.println("Jugador 2: " + Jugador2.getGanadas()+"\n");
            JuegoAhorcado p = new JuegoAhorcado();
            numPartidas++;
            System.out.println("----------------------------------\n");
            System.out.println("<<<<<  Partida " + numPartidas + " >>>>>");
            
            if(i%2==0) //turno para introducir palabras
            {
                System.out.println("El jugador 1 introduce palabra: ");
                palabraParaAdivinar = Jugador1.introducirPalabra(); 
                j=1;
                
            } else {
                 System.out.println("El jugador 2 introduce palabra: ");
                 palabraParaAdivinar = Jugador2.introducirPalabra();
                 j=2;  
            }
            i++;
            inicializarAdivinada();
            int opcion;
            do{
                dibujarAhorcado();
                System.out.printf("\n");
                palabraAdivinada.mostrarEspecial();
                System.out.printf("\n");
                System.out.println("Letras usadas: " + letrasUsadas);
                System.out.printf("\n");
                System.out.println("+------- MENÚ DE OPCIONES -----+");
                System.out.println("|  1. Elegir letra.            |");         
                System.out.println("|  2. Acertar palabra.         |");
                System.out.println("|  3. Abandonar partida.       |");
                System.out.println("+------------------------------+");
                System.out.println(" --> Introduzca una opción:");
                opcion = entero.nextInt();
                switch (opcion) {
                    case 1:
                        System.out.printf("Introduce letra a buscar: ");
                        letra = entero.next().charAt(0);
                        boolean cierto=false;
                        cierto = preguntarLetra(letra);
                        if (cierto == false) {
                            pierdeVida();
                            guardarUsadas(letra);
                        }
                        break;
                    case 2:
                        String s;
                        System.out.printf("Introduzca palabra para adivinar: ");
                        s = sx.nextLine();
                        if (palabraParaAdivinar.getPalabra().equals(s)) {
                            palabraAdivinada.setPalabra(s);
                        } else {
                            System.out.println("Palabra incorrecta.");
                            pierdeVida();
                        }
                        break;
                    case 3:
                        System.out.println("Abandonando partida...");
                        System.exit(0);
                        break;
                    default:
                        System.out.println("ERROR: Opción inválida.");
                }
            }while ((acierta() == false) && (getVidas() > 0) && opcion!=3);

            if (acierta()) {
                
                if(j==1)//si es el jugador 1 el que escribe la palabra 
                {
                    System.out.println("¡Has acertado la palabra!");
                    Jugador2.setGanadas(Jugador2.getGanadas() + 1);
                }else{
                    System.out.println("¡Has acertado la palabra!");
                    Jugador1.setGanadas(Jugador1.getGanadas() + 1);
                }
                
                vidas = 6;
            } else {
                if(j==1)
                {
                    System.out.println("Has perdido.");
                    Jugador1.setGanadas(Jugador1.getGanadas() + 1);
                }
                else{
                     System.out.println("Has perdido.");
                    Jugador2.setGanadas(Jugador2.getGanadas() + 1);
                }
                
            }
            if(Jugador1.ganador()||Jugador2.ganador())
                System.out.println("\n>>>------- FIN DE PARTIDA ------<<<");
            if (Jugador1.ganador()) {
                System.out.println("Ganador: jugador 1.");
            } else if (Jugador2.ganador()) {
                System.out.println("Ganador: jugador 2.\n");
            }
            if(Jugador1.ganador()||Jugador2.ganador()){
                System.out.println("MARCADOR:");
                System.out.println("Jugador 1: " + Jugador1.getGanadas());
                System.out.println("Jugador 2: " + Jugador2.getGanadas()+"\n");
                System.out.println(">>>-----------------------------<<<");
            }
        }
    }
}
