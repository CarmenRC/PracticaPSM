
package juegoahorcado;

/**
 *
 * @author usuario
 */
public class Palabra {
    
    private String palabra;

    public Palabra (String a)
    {
        palabra = a;
    }
        
    public String getPalabra() {
        return palabra;
    }

    public void setPalabra(String p) {
        this.palabra = p;
    }
    
    public int numeroLetras()
    {
        return palabra.length();
    }
    
    public void mostrarEspecial()
    {
        System.out.println("Palabra: ");
        for (int i = 0; i < palabra.length(); i++) {
                System.out.printf(" " + palabra.charAt(i));  
        }
    }
    
}
