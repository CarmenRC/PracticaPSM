
package juegoahorcado;

import java.util.Scanner;

/**
 *
 * @author usuario
 */
public class Jugador {
    
    private int ganadas; //numero de jugadas ganadas
    private String idJugador; //identificador jugador

    /**
     * 
     * @return número de partidas ganadas
     */
    public int getGanadas() {
        return ganadas;
    }

    /**
     * 
     * @return id del jugador
     */
    public String getIdJugador() {
        return idJugador;
    }
    
    public void setGanadas(int ganadas) {
        this.ganadas = ganadas;
    }

    public void setNombre(String id) {
        this.idJugador = id;
    }
    
    public Palabra introducirPalabra()
    {
        Scanner sc = new Scanner(System.in);
        String p;
        System.out.println("Escribe la palabra a adivinar: ");
        p=sc.nextLine();
        Palabra pal = new Palabra(p);
        return pal;  
    }
    
    public boolean ganador()
    {
        if(ganadas==3)
            return true;
        else
            return false;
    }  
}
